

/*
  	Filename: Resort.java
	  Author: Rutvik Patel
	    Date: 29-Mar-2024 6:17:48 pm
 Description: Resort module that contains all the details and methods of resort.
*/


class Resort extends Travel {
	String resortName;
	int unitNumber;
	String unitType;
	
	//Constructor one
	Resort(String destination, int duration,String resortName,  int unitNumber, String unitType, String activity[]){
		super(destination, resortName, unitNumber,activity);
		this.resortName = resortName;
		this.unitType = unitType;
		this.unitNumber = unitNumber;

	}
	//constructor two
	Resort(String destination, int duration, String resortName, String resortType, int unitNumber, String unitType, String activity[]){
		super(destination, resortType ,unitNumber, activity);
	}
	
	//getters for river
	public String getResortName() {
		return this.resortName;
	}
	public int getUnitNumber() {
		return this.unitNumber;
	}
	
	public String getUnitType() {
		return this.unitType;
	}
	
	//setter
	public void setResortName(String resortName) {
		this.resortName=resortName;
	}
	public void setunitNumber(int unitNumber) {
		this.unitNumber=unitNumber;
	}
	public void setunitType(String unitType) {
		this.unitType=unitType;
	}
	

		
	// overriding methods 
	
	@Override
	public String describeTrip()
	{
		return "This is a resort vacation.  You will be staying at the "+getResortName()+" resort which is located in "+getDestination() +" and will provide you with "
				+ getDuration() +" days of relaxation";
	}

	@Override
	public String showAccommodations()
	{
		return "You have been assigned to a(n) "+getUnitType()+" identified by unit " + getUnitNumber();
	}

	@Override
	public void listActivities()
	{
		System.out.println("Here are the activities available to you at the "+ getResortName() +" resort in "+getDestination()+" \n");
		for(String e: getActivities()) {
			System.out.println(e);	
		}
	}
}