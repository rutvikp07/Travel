
/*
  	Filename: RiverCruise.java
	  Author: Vijul Vyas
	    Date: 29-Mar-2024 6:16:53 pm
 Description: River cruise module that contains all the details and methods of river cruise.
*/

class RiverCruise extends Cruise{
	String river;
	RiverCruise(String destination, int duration, String cruiseLine, String shipName, int roomNumber,String accommodationType,String activity[], String river)
	{
		super(destination, duration, cruiseLine, shipName, roomNumber, accommodationType, activity);
		this.river = river;
		
	}
	
	//getters for river
	public String getRiver() {
		return this.river;
	}
	
	//setters
	public void setRiver(String river) {
		this.river=river;
	}
	
	
	//overriding methods
	public String describeTrip() {
		
		return "The "+ getShipName()+" belongs to the "+ getCruiseLine()+" cruise line.\r\n"
				+ "This ship is headed to "+getDestination()+" and is "+getDuration()+" days in duration. \nThis river cruise will afford you the opportunity to explore the "+getRiver()+" river";
		
	}
	
	@Override
	public String showAccommodations()
	{
		return "You are booked into room #"+getRoomNumber()+" which is a(n) "+getAccommodationType();
	}
	@Override
	public void listActivities()
	{
		System.out.println("Here are the activities available on board the "+getCruiseLine()+" "+getShipName()+":\n");
		for(String e: getActivities()) {
			System.out.println(e);	
		}
	}
}