
/*
  	Filename: AllInclusive.java
	  Author: Rutvik Patel
	    Date: 29-Mar-2024 6:19:16 pm
 Description: All inclusive module that contains all the details and methods of All inclusive.
*/

class AllInclusive extends Resort 
{
	int drinkLimit;
	int diningFacilities;
	
	//constructor 
	AllInclusive(String destination,int duration,String resortName,int unitNumber,String unitType,String activity[], int drinkLimit, int diningFacilities)
	{
		super(destination, duration, resortName, unitNumber, unitType, activity);
		this.drinkLimit = drinkLimit;
		this.diningFacilities = diningFacilities;
	}
	
	//getters
	public int getDrinkLimit() {
		return drinkLimit;
	}
	public int getDiningFacilities() {
		return diningFacilities;
	}
	
	//setters
	public void setDrinkLimit(int drinkLimit) {
		this.drinkLimit = drinkLimit;
	}
	public void setDiningFacilities(int diningFacilities){
		this.diningFacilities = diningFacilities;
	}

	
		// overriding methods

			public String describeTrip()
		{
			return "This is an all inclusive resort vacation.  You will be staying at the "+ getResortName() +" resort which is located in "+ getDestination() +" and will provide you with "+ getDuration()+" days of relaxation. Your purchase provides for "+getDrinkLimit()+" alcoholic drinks per day and a choice of "+getDiningFacilities()+" fabulous dining facilities with something for every palate.";
		}

		@Override
		public String showAccommodations()
		{
			return "You have been assigned to a(n) "+getUnitType()+" suite identified by unit #"+getUnitNumber();
		}

		
		public void listActivities()
		{
			System.out.println("Here are the activities available to you at the "+ getResortName() +" resort in "+getDestination()+" \n");
			
			
			for(String e: getActivities()) {
				System.out.println(e);	
			}
		}
}
