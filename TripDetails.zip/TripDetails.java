
/*
  	Filename: TripDetails.java
	  Author: Rutvik Patel
	    Date: 29-Mar-2024 6:28:35 pm
 Description: Trip detail file which contains the main module and all the objects
*/
public class TripDetails 
{

  public static void main(String[] args) {
  	
  	//defining activities  
  	String[] cruiseActivities = {"3 Pools", "Mini golf", "4 hot tubs", "Basketball court", "4 shuffle board play areas", "Library", "Fitness centre", "Spa", "3 waterslides", "Arcade", "Theatre", "Bingo"};
    String[] riverCruiseActivities = {"Pool", "2 hot tubs", "Library", "Spa", "Bingo", "Comedy club"};
    String[] resortActivities = {"5 Pools", "Golf course", "6 hot tubs", "Tennis Court", "Shuffle board", "Horse shoes", "Fitness centre", "Archery", "Water sports"};
    String[] allInclusiveActivities = {"2 Pools", "Mini golf", "Golf course", "Hot tub", "Basketball court", "Fitness centre", "Spa", "Waterslide", "Movie theatre", "Bingo", "Water sports", "Island tours"};
    Cruise cruise = new Cruise("Caribbean", 9, "Carnival", "Magic", 7078, "Balcony", cruiseActivities);
    RiverCruise riverCruise = new RiverCruise("European", 14, "Avalon", "Envision", 3014, "River view", riverCruiseActivities, "Rhine");
    Resort resort = new Resort("Dominican Republic", 7, "Swindles", 14, "Junior", resortActivities);
    AllInclusive allInclusive = new AllInclusive("Tahiti", 14, "SunDrench Resort", 35, "Family", allInclusiveActivities, 14, 10);
    
    
    //printing output ------------------------------------------------------------
    System.out.println("\t\t\t\tWelcome to Fanshawe Travel Agency\r\n"
    		+ "\t\t\t\t*********************************\n"
    		+ "We have researched four fabulous vacation getaways for you and now offer them to you for your perusal.");
    	System.out.println();
    	System.out.println("Here are the details for your cruise selection:");
    	System.out.println("Destination: "+ cruise.getDestination());
    	System.out.println("Cruise Line: "+ cruise.getCruiseLine());
    	System.out.println("Ship Name: "+ cruise.getShipName());
    	System.out.println("Duration: "+ cruise.getDuration()+" days");
    	System.out.println("Accommodation Type: "+ cruise.getAccommodationType());
    	System.out.println("Destination: "+ cruise.getRoomNumber());

    	System.out.println();
      
    	System.out.println("Here are the details for your river cruise selection:");
    	System.out.println("Destination: "+ riverCruise.getDestination());
    	System.out.println("River: "+ riverCruise.getRiver());
    	System.out.println("Cruise Line: "+ riverCruise.getCruiseLine());
    	System.out.println("Ship Name: "+ riverCruise.getShipName());
    	System.out.println("Duration: "+ riverCruise.getDuration()+" days");
    	System.out.println("Accommodation Type: "+ riverCruise.getAccommodationType());
    	System.out.println("Destination: "+ riverCruise.getRoomNumber());
    	
    	System.out.println();

    	System.out.println("Here are the details for your resort selection:");
    	System.out.println("Destination: "+ resort.getDestination());
    	System.out.println("Resort Name: "+ resort.getResortName());
    	System.out.println("Unit Type: "+ resort.getType());
    	System.out.println("Your Unit Number: "+ resort.getUnitNumber());
    	System.out.println("Vacation duration: "+ resort.getDuration()+" days");
    	
    	System.out.println();
      
    	System.out.println("Here are the details for your all inclusive resort selection:");
    	System.out.println("Destination: "+ allInclusive.getDestination());
    	System.out.println("Resort Name: "+ allInclusive.getResortName());
    	System.out.println("Unit Type: "+ allInclusive.getUnitType());
    	System.out.println("Your Unit number "+ allInclusive.getUnitNumber());
    	System.out.println("Vacation duration: "+ allInclusive.getDuration()+" days");
    	System.out.println("Drink Limit: "+ allInclusive.getDrinkLimit());
    	System.out.println("Dining facilities: "+ allInclusive.getDiningFacilities());
    	
    	
    	System.out.println();
   
    		
      resort.setDestination("Jamaica");
      resort.setDuration(21);
      resort.setResortName("Sandals");
      resort.setunitNumber(42);
      resort.setunitType("Studio");
      
    System.out.println("-------------------------------------------------");
    Travel[] travels = {cruise, riverCruise, resort, allInclusive};
    for (Travel travel : travels) {
        System.out.println(travel.describeTrip());
        System.out.println(travel.showAccommodations());
        travel.listActivities();
        System.out.println("-------------------------------------------------");
    }	
    riverCruise.addActivity("a game room");
    riverCruise.listActivities();
    System.out.println();
    allInclusive.removeActivity("Hot tub");
    allInclusive.listActivities();
    
    System.out.println(" ");
    System.out.println("Thank you for contacting Fanshawe Travel Agency.\r\n"
    		+ "We believe we have put together some amazing vacations for your enjoyment.\r\n"
    		+ "Please contact us if you would like to book one of these exciting opportunities.");
  }
}
