
/*
  	Filename: Travel.java
	  Author: Vijul Vyas
	    Date: 29-Mar-2024 1:11:20 pm
 Description: Parent class having all the super constructors, methods and variables.
*/

import java.util.Arrays;

public abstract class Travel
{
	//defining variables
	private String destination;
	private String type;
	private int duration;
	private String activities[];
	
	//constructor 
	public Travel(String destination,String type,int duration, String[] activities) {
		this.destination = destination;
		this.type = type;
		this.duration = duration;
		this.activities = activities;
	}
	//Getters
	public String getDestination() {
		return this.destination;
	}
	public String getType() {
		return this.type;
	}
	public int getDuration() {
		return this.duration;
	}
	public String[] getActivities() {
		return this.activities;
	}
	
	//Setters
	public  void setDestination(String destination) {
		 this.destination=destination;
	}
	public  void setType(String type) {
		 this.type=type;
	}
	public void setDuration(int duration) {
		 this.duration=duration;
	}
	
	
	//methods for details
	public abstract String describeTrip();

  public abstract String showAccommodations();

  public abstract void listActivities();
  {

  }
  //add activities method
  public void addActivity(String activity) {
  	System.out.println("Please be advised that the "+getClass().getSimpleName()+" vacation has added an additional activity:\r\nPlease note the addition in the following list of activities available to you"); 
  	System.out.println(" ");
    activities = Arrays.copyOf(activities, activities.length + 1);
    activities[activities.length - 1] = activity;
    }
  //remove activity method
  public void removeActivity(String activity) {
  	System.out.println("Please be advised that the "+ getClass().getSimpleName() +" vacation has removed one of its activities:\r\nPlease note the reduced number of activities now available to you:"); 
  	System.out.println(" ");
  	for (int i = 0; i < activities.length; i++) {
        if (activities[i].equals(activity)) {
            activities[i] = activities[activities.length - 1];
            activities = Arrays.copyOf(activities, activities.length - 1);
            break;
        }
    }
}
  


}

