
/*
  	Filename: Cruise.java
	  Author: Vijul Vyas
	    Date: 29-Mar-2024 6:14:01 pm
 Description: Cruise module that contains all the details and methods of Cruise.
*/

class Cruise extends Travel{
	
	String cruiseLine;
	String shipName;
	int roomNumber;
	String accommodationType;

	//constructor one
	Cruise(String destination,int duration ,String cruiseLine,String shipName, int roomNumber, String accommodationType, String activities[])
	{
		super(destination,cruiseLine,duration , activities);
		this.cruiseLine = cruiseLine;
    this.shipName = shipName;
    this.roomNumber = roomNumber;
    this.accommodationType = accommodationType;
	}
	
	//constructor two
	Cruise(String destination, String cruiseType,int duration, String cruiseLine, String shipName, int roomNumber, String accommodationType,String[] activities)
	{
		super(destination, cruiseType, duration, activities);
	}

	
	
	//getters
	public String getCruiseLine() {
		return this.cruiseLine;
	}
	public String getShipName() {
		return this.shipName;
	}
	public int getRoomNumber() {
		return this.roomNumber;
	}
	public String getAccommodationType() {
		return this.accommodationType;
	}
	
	
	//Setters
	public void setCruiseLine(String cruiseLine) {
		 this.cruiseLine = cruiseLine;
	}
	public void setShipName(String shipName) {
		 this.shipName= shipName;
	}
	public void setRoomNumber(int roomNumber) {
		 this.roomNumber=roomNumber;
	}
	public void setAccommodationType(String accommodationType) {
		this.accommodationType = accommodationType;
	}
	
	
	//overriding methods 
	
	@Override
	public String describeTrip()
	{
		return "The "+ getShipName()+" belongs to the "+ getCruiseLine()+" Cruise line.\r\n"
				+ "This ship is headed to "+ getDestination() +" and is "+ getDuration() +"days in duration.\r\n";	
	}
	@Override
	public String showAccommodations()
	{
		return "You are booked into room #"+getRoomNumber()+" which is a(n) "+getAccommodationType();
	}
	@Override
	public void listActivities()
	{
		System.out.println("Here are the activities available on board the "+getCruiseLine()+" "+getShipName()+":\n");
		for(String e: getActivities()) {
			System.out.println(e);
		}
	}
	
}